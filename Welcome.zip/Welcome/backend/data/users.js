// users.js

const users = [
    { username: 'user1', password: '$2b$10$WP04kMKnXprnYesrTLePl.eNWosjLvsvLKdYqZhsri8PEk7Vlsmki' },
];

module.exports = users;
