Yarn install
Yarn start